import assert from "assert";
import * as web3 from "@solana/web3.js";
import * as anchor from "@coral-xyz/anchor";
import * as anchor from "@coral-xyz/anchor";
import { assert } from "chai";
import type { Counter } from "../target/types/counter";

describe("Counter Program", () => {
  // Configure the client to use the local cluster
  anchor.setProvider(anchor.AnchorProvider.env());

  const program = anchor.workspace.Counter as anchor.Program<Counter>;
  
  const provider = anchor.AnchorProvider.env();
  anchor.setProvider(provider);

  const program = anchor.workspace.Counter as anchor.Program;

  let counterKeypair: anchor.web3.Keypair;

  // Inicializar antes de correr los tests
  before(async () => {
    counterKeypair = anchor.web3.Keypair.generate();

    await program.methods.initialize()
      .accounts({
        counter: counterKeypair.publicKey,
        user: provider.wallet.publicKey,
        systemProgram: anchor.web3.SystemProgram.programId,
      })
      .signers([counterKeypair])
      .rpc();
  });

  it("Debe iniciar en 0", async () => {
    const account = await program.account.counter.fetch(counterKeypair.publicKey);
    assert.equal(account.count.toNumber(), 0, "El contador debe iniciar en 0");
  });

  it("Debe incrementar a 1", async () => {
    await program.methods.increment()
      .accounts({
        counter: counterKeypair.publicKey,
      })
      .rpc();

    const account = await program.account.counter.fetch(counterKeypair.publicKey);
    assert.equal(account.count.toNumber(), 1, "El contador debe ser 1 después de incrementar");
  });
});
