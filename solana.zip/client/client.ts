import * as web3 from "@solana/web3.js";
import * as anchor from "@coral-xyz/anchor";
import * as anchor from "@coral-xyz/anchor";
import type { Counter } from "../target/types/counter";

// Configure the client to use the local cluster
anchor.setProvider(anchor.AnchorProvider.env());

const program = anchor.workspace.Counter as anchor.Program<Counter>;


const main = async () => {
  const provider = anchor.AnchorProvider.env();
  anchor.setProvider(provider);

  const program = anchor.workspace.Counter as anchor.Program;

  // Generar cuenta para el contador
  const counterKeypair = anchor.web3.Keypair.generate();

  // Inicializar
  await program.methods.initialize()
    .accounts({
      counter: counterKeypair.publicKey,
      user: provider.wallet.publicKey,
      systemProgram: anchor.web3.SystemProgram.programId,
    })
    .signers([counterKeypair])
    .rpc();

  console.log("Cuenta creada:", counterKeypair.publicKey.toBase58());

  // Incrementar
  await program.methods.increment()
    .accounts({
      counter: counterKeypair.publicKey,
    })
    .rpc();

  // Leer valor
  const account = await program.account.counter.fetch(counterKeypair.publicKey);
  console.log("Valor actual del contador:", account.count.toNumber());
};

main().catch(err => console.error("Error en cliente:", err));

  console.error("Error ejecutando cliente:", err);
});
